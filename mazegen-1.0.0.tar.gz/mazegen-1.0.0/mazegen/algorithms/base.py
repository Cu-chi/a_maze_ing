from abc import ABC, abstractmethod
from enum import Enum
from mazegen.utils import grid


class Algorithm(Enum):
    """All supported algorithms
    """

    DFS = "DFS"
    """Depth-First-Search algorithm"""

    HAK = "HAK"
    """Hunt-And-Kill algorithm"""

    DFS_NOT_PERFECT = "DFS_NOT_PERFECT"
    """Depth-First-Search algorithm but not perfect because we
    break random walls"""


class BaseAlgorithm(ABC):
    def __init__(self, grid_: grid) -> None:
        """Initialize the algorithm

        Args:
            grid_ (grid): the grid of the maze
        """
        self.grid: grid = grid_

    @abstractmethod
    def generate(self) -> grid:
        pass
